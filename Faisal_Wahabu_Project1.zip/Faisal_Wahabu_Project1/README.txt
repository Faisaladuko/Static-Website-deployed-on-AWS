Name:  Faisal Aduko Wahabu
Project: Deploy Static Website on AWS
Submission Date : 22nd May, 2022.


Cloudfront Endpoint URL:   http://faisal-project1-bucket.s3-website-us-east-1.amazonaws.com/

Cloudfront Domain name:    https://d1bl3kjo4wn30y.cloudfront.net/

S3 Object URL:   http://faisal-project1-bucket.s3.amazonaws.com/index.html